package com.example.BookstoreAPI.Service;


import com.example.BookstoreAPI.Controller.CustomerController;
import com.example.BookstoreAPI.DTO.CustomerDTO;
import com.example.BookstoreAPI.Entity.Customer;
import com.example.BookstoreAPI.Repository.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ModelMapper modelMapper;

    public List<CustomerDTO> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        return customers.stream()
                .map(this::convertToDTOWithLinks)
                .collect(Collectors.toList());
    }

    public CustomerDTO getCustomerById(Long id) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        return convertToDTOWithLinks(customer);
    }

    private CustomerDTO convertToDTOWithLinks(Customer customer) {
        CustomerDTO customerDTO = modelMapper.map(customer, CustomerDTO.class);

        // Add self-link
        Link selfLink = WebMvcLinkBuilder.linkTo(
                        WebMvcLinkBuilder.methodOn(CustomerController.class).getCustomerById(customer.getId()))
                .withSelfRel();
        customerDTO.add(selfLink);

        // Add link to all customers
        Link allCustomersLink = WebMvcLinkBuilder.linkTo(
                        WebMvcLinkBuilder.methodOn(CustomerController.class).getAllCustomers())
                .withRel("all-customers");
        customerDTO.add(allCustomersLink);

        return customerDTO;
    }
}
