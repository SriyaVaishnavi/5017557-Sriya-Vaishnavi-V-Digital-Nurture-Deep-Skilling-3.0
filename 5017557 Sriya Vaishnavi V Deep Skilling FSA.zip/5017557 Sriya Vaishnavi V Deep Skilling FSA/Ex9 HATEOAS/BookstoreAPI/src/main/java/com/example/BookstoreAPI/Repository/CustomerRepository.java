package com.example.BookstoreAPI.Repository;

import com.example.BookstoreAPI.Entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
