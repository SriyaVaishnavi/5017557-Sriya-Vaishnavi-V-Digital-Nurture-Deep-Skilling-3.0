package com.example.BookstoreAPI.DTO;

public class BookDTO {
}
