package com.example.BookstoreAPI.Controller;


import com.example.BookstoreAPI.exception.BookNotFoundException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.BookstoreAPI.Entity.Book;
import com.example.BookstoreAPI.Service.BookService;

@RestController
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable Long id) {
        Book book = bookService.findBookById(id).orElseThrow(() -> new BookNotFoundException(id));

        HttpHeaders headers = new HttpHeaders();
        headers.add("Custom-Header", "Book Retrieved");

        return new ResponseEntity<>(book, headers, HttpStatus.OK);
    }
}
