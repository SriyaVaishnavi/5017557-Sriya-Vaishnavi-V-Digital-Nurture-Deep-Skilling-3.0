package com.example.Employee.Management.System.Projection;

public interface EmployeeProjection {
    Long getEmployeeId();
    String getEmployeeName();
    String getEmployeeEmail();
    String getEmployeedept();
}
