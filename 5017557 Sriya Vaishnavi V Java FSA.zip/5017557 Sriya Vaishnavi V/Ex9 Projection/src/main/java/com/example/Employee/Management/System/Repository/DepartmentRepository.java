package com.example.Employee.Management.System.Repository;

import com.example.Employee.Management.System.DTO.DepartmentDTO;
import com.example.Employee.Management.System.Entities.Department;
import com.example.Employee.Management.System.Projection.DepartmentProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Use projection to get specific fields
    @Query("SELECT new com.example.Employee.Management.System.DTO.DepartmentDTO(d.id, d.name) FROM Department d")
    List<DepartmentDTO> findDepartmentDTOs();
}

