package com.example.Employee.Management.System.Config;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Return the current user or any identifier for the auditing user
        // For example, you could get this from the security context
        return Optional.of("System User"); // Replace with actual user logic
    }


}
