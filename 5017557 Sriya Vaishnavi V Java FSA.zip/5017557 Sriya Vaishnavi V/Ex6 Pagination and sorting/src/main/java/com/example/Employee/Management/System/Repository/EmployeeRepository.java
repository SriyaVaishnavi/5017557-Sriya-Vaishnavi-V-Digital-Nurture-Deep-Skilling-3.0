package com.example.Employee.Management.System.Repository;

import com.example.Employee.Management.System.Entities.Employee;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

import java.awt.print.Pageable;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    Page<Employee> findAll(Pageable pageable);

    // Custom methods with pagination and sorting
    Page<Employee> findByEmployeenameContaining(String Employeename, Pageable pageable);
}
