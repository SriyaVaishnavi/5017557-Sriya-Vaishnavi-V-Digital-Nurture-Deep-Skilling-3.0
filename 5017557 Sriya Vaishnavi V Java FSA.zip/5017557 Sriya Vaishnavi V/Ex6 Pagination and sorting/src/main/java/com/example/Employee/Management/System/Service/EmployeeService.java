package com.example.Employee.Management.System.Service;

import com.example.Employee.Management.System.Entities.Employee;
import com.example.Employee.Management.System.Repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import java.awt.print.Pageable;
import java.util.List;

@Service
public class EmployeeService {
    private EmployeeRepository employeeRepository;

    // Method to get paginated list of employees
    public Page<Employee> getEmployees(Pageable pageable) {
        return employeeRepository.findAll(pageable);
    }

    // Method to search employees with pagination
    public Page<Employee> searchEmployeesByFirstName(String firstName, Pageable pageable) {
        return employeeRepository.findByEmployeenameContaining(firstName, pageable);
    }
}


