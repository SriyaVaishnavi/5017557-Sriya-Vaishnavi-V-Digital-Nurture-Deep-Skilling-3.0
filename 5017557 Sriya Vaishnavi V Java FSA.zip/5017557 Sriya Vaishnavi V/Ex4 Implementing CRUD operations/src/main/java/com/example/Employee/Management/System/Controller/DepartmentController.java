package com.example.Employee.Management.System.Controller;



import com.example.Employee.Management.System.Entities.Department;
import com.example.Employee.Management.System.Service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

    @RestController
    @RequestMapping("/api/departments")
    public class DepartmentController {

        @Autowired
        private DepartmentService departmentService;

        // GET all departments
        @GetMapping
        public List<Department> getAllDepartments() {
            return departmentService.getAllDepartments();
        }

        // GET department by ID
        @GetMapping("/{id}")
        public ResponseEntity<Department> getDepartmentById(@PathVariable Integer id) {
            Department department = departmentService.getDepartmentById(id);
            return ResponseEntity.ok(department);
        }

        // POST create a new department
        @PostMapping
        public Department createDepartment(@RequestBody Department department) {
            return departmentService.saveDepartment(department);
        }

        // PUT update an existing department
        @PutMapping("/{id}")
        public ResponseEntity<Department> updateDepartment(@PathVariable Integer id, @RequestBody Department departmentDetails) {
            Department updatedDepartment = departmentService.updateDepartment(id, departmentDetails);
            return ResponseEntity.ok(updatedDepartment);
        }

        // DELETE a department
        @DeleteMapping("/{id}")
        public ResponseEntity<Void> deleteDepartment(@PathVariable Integer id) {
            departmentService.deleteDepartment(id);
            return ResponseEntity.noContent().build();
        }
    }


