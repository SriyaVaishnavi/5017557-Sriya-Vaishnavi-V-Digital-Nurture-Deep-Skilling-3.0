package com.example.Employee.Management.System.service;

import com.example.Employee.Management.System.entiity.secondary.secondaryentity;
import com.example.Employee.Management.System.repository.secondary.secondaryrepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SecondaryService {
    @PersistenceContext(unitName = "secondaryEntityManagerFactory")
    private EntityManager secondaryEntityManager;

    public void performSecondaryOperation() {
    }

    @Autowired
    private secondaryrepository secondaryRepository;

    public secondaryentity saveSecondaryEntity(secondaryentity entity) {
        secondaryRepository.save(entity);
        return entity;
    }

    public secondaryentity getSecondaryEntity(Long id) {
        return secondaryRepository.findById(id).orElse(null);
    }
}
