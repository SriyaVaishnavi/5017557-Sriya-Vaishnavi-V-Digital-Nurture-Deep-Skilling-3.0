package com.example.Employee.Management.System.controller;

import com.example.Employee.Management.System.entiity.secondary.secondaryentity;
import com.example.Employee.Management.System.service.SecondaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/secondary")
public class SecondaryController {

    @Autowired
    private SecondaryService secondaryService;

    @PostMapping("/save")
    public secondaryentity saveSecondaryEntity(@RequestBody secondaryentity entity) {
        return secondaryService.saveSecondaryEntity(entity);
    }

    @GetMapping("/{id}")
    public secondaryentity getSecondaryEntity(@PathVariable Long id) {
        return secondaryService.getSecondaryEntity(id);
    }
}
