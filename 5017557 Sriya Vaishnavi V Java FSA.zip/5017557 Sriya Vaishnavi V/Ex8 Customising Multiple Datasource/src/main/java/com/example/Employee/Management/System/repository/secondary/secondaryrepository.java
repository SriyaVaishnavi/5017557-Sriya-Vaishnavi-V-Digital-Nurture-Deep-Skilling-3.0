package com.example.Employee.Management.System.repository.secondary;

import com.example.Employee.Management.System.entiity.secondary.secondaryentity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface secondaryrepository extends JpaRepository<secondaryentity, Long> {
}
