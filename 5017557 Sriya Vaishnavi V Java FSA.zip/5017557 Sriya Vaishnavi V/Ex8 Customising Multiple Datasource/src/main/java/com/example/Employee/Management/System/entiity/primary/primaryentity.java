package com.example.Employee.Management.System.entiity.primary;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

    @Setter
    @Getter
    @Entity
    public class primaryentity {
        @Id
        private Long id;
        private String name;

    }


