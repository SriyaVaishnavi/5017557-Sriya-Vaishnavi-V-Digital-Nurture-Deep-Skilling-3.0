public class Book {
    private String title;
    private int bookid;
    private String author;

    public Book(String title,String author, int bookid){
        this.bookid=bookid;
        this.title=title;
        this.author=author;
    }
    //getters
    public String getTitle(){
        return title;
    }
    public int getBookid(){
        return bookid;
    }
    public String getAuthor(){
        return author;
    }

    @Override
    public String toString() {
        return "book{ bookid=" + bookid + " " +
                "title=" + title + " " +
                "author=" + author +
                "}";

    }
}
