import java.util.List;

public class linearsearch {
    public static product linearsearch(List<product> productList, int productID) {
        for (product product : productList) {
            if (product.getProductid() == productID) {
                return product;
            }
        }
        return null; // return null if the productID is not found
    }
}