public class product {
    private int productid;
    private String productname;
    private String category;

    public product(int productid,String productname,String category){
        this.productid=productid;
        this.productname=productname;
        this.category=category;
    }

    public int getProductid() {
        return productid;
    }

    public String getProductname() {
        return productname;
    }

    public String getCategory() {
        return category;
    }
    @Override
    public String toString() {
        return "product{ productid=" + productid +" "+
                "name=" + productname +" "+
                "category=" + category+
        "}";
    }


    }

