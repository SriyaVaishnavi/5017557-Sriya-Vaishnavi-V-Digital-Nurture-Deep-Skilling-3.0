import java.util.Scanner;

public class productsearch {
    public static void main(String[] args) {
        inventory inventory = new inventory();
        Scanner sc = new Scanner(System.in);

        // Adding items
        inventory.addItem(new product(1, "POCO C65", "SMART DEVICES"));
        inventory.addItem(new product(2, "CHOCLATES", "GROCERIES"));

        // Display inventory
        System.out.println("Initial Inventory:");
        inventory.displayInventory();

        // Search for a product
        System.out.println("Enter the product id:");
        int searchVal = sc.nextInt();
        product searchProd = linearsearch.linearsearch(inventory.getProductList(), searchVal);

        if (searchProd != null) {
            System.out.println("linear search Product found: " + searchProd);
        } else {
            System.out.println("Product with ID " + searchVal + " not found.");
        }
        product searchProd1=binarysearch.binarysearch(inventory.getSortedProductList(),searchVal,inventory.getSortedProductList().size());
        if (searchProd1 != null) {
            System.out.println("Binary Search Product found: " + searchProd1);
        } else {
            System.out.println("Product with ID " + searchVal + " not found.");
        }
        // Display inventory after update
        System.out.println("\nInventory after searching:");
        inventory.displayInventory();





        sc.close();
    }


}