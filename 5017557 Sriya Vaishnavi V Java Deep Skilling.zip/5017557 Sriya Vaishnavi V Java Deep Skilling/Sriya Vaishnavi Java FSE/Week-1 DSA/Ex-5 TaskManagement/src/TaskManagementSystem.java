public class TaskManagementSystem {
    public static void main(String[] args) {
        TaskManager taskManager = new TaskManagerImpl();

        // Adding tasks
        taskManager.addTask(new Task(1, "Complete assignment", "Completed"));
        taskManager.addTask(new Task(2, "Prepare for meeting",  "Pending"));
        taskManager.addTask(new Task(3, "Conduct Analysis",  "Completed"));

        // Traverse tasks
        System.out.println("All Tasks:");
        taskManager.traverseTasks();

        // Search a task
        System.out.println("\nSearching for Task with ID 2:");
        Task task = taskManager.searchTask(2);
        if (task != null) {
            System.out.println(task);
        } else {
            System.out.println("Task not found.");
        }

        // Delete a task
        System.out.println("\nDeleting Task with ID 2:");
        taskManager.deleteTask(2);

        // Traverse tasks after deletion
        System.out.println("\nAll Tasks after deletion:");
        taskManager.traverseTasks();
    }
}
