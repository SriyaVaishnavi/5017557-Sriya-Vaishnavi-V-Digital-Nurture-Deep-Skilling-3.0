import java.util.*;
import java.util.Scanner;

public class ordersearch {
    public static void main(String[] args) {
        ordermanagement neworder = new ordermanagement();
        bubblesort sorter = new bubblesort();

        // Adding items
        neworder.addItem(new order(1, "GADGETS", 55.0));
        neworder.addItem(new order(2, "APPLIANCES", 16));
        neworder.addItem(new order(2, "BABYCARE", 42.0));
        neworder.addItem(new order(3, "FURNITURE", 29.5));
        neworder.addItem(new order(4, "HOME SUPPLIES", 55.0));
        neworder.addItem(new order(5, "CLOTHING", 33.75));
        neworder.addItem(new order(6, "MOBILES", 48.0));


        // Display inventory
        System.out.println("Initial Inventory:");
        ArrayList<order> sortedOrders=sorter.bubblesort(neworder.getorderList());
        System.out.println("Bubble sorted Orders: " + sortedOrders);
        ArrayList<order> Quicksortedarray=Quicksort.quicksort(neworder.getorderList(),0,neworder.getorderList().size()-1);
        System.out.println("Quick Sorted Orders: " + Quicksortedarray);




        // Search for a product

    }
}
