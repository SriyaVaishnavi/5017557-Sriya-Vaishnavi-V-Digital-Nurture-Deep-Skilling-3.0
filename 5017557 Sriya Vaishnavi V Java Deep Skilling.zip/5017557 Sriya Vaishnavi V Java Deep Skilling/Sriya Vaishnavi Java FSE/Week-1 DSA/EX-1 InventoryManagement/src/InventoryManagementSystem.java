//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

public class InventoryManagementSystem {
    public static void main(String[] args) {
        inventory inventory = new inventory();

        // Adding items
        inventory.addItem(new product(01, "Oppo", 2, 50000));
        inventory.addItem(new product(02, "Realme", 100, 2000000));

        // Display inventory
        System.out.println("Initial Inventory:");
        inventory.displayInventory();

        // Update item quantity
        inventory.updateItemQuantity("Oppo", 60);

        // Display inventory after update
        System.out.println("\nInventory after updating Apple quantity:");
        inventory.displayInventory();

        // Remove an item
        inventory.removeItem("Realme");

        // Display inventory after removing an item
        System.out.println("\nInventory after removing Realme:");
        inventory.displayInventory();
    }
}