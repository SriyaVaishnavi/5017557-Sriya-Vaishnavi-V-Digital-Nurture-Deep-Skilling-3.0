import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class Logger {
    // Private static instance of the singleton class
    private static Logger instance;

    // File writer
    private BufferedWriter writer;

    // Private constructor to prevent instantiation
    private Logger() {
        try {
            // Initialize the writer with the log file path
            writer = new BufferedWriter(new FileWriter("app.log", true));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Public static method to provide access to the singleton instance
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // Enum for log levels


    // Method to log messages with different log levels
    public void log(String message) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
        String logMessage = timestamp + " : " + message;

        // Print to console
        System.out.println(logMessage);

        // Write to file
        try {
            writer.write(logMessage);
            writer.newLine();
            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void info(String message) {
        log( message);
    }

}
