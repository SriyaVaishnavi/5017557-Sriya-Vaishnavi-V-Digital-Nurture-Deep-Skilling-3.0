public class NotificationService {
    public static void main(String[] args) {
        // Basic Notifier
        Notifier notifier = new EmailNotifier();
        notifier.send("Hello!");

        System.out.println();

        // Notifier with SMS
        Notifier smsNotifier = new SMSNotifierDecorator(new EmailNotifier());
        smsNotifier.send("Hello!");

        System.out.println();

        // Notifier with Email and SMS
        Notifier emailAndSMSNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(new EmailNotifier()));
        emailAndSMSNotifier.send("Hello!");
    }
}
