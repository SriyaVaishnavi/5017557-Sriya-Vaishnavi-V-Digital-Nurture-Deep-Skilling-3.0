public interface Image {
    public void display();
}
