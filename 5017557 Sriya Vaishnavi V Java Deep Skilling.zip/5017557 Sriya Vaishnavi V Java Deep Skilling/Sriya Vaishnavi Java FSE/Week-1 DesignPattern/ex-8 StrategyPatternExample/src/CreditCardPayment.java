public class CreditCardPayment implements PaymentStrategy {
    private String cardNumber;
    private double balance;
    private double creditLimit;
    private String CardHolderName;
    public CreditCardPayment(String cardNumber, double balance, double creditLimit,String CardHolderName) {
        this.cardNumber = cardNumber;
        this.balance = balance;
        this.creditLimit = creditLimit;
        this.CardHolderName = cardNumber;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paying " + amount + " on card " + cardNumber + " with balance " + balance);
    }
}
