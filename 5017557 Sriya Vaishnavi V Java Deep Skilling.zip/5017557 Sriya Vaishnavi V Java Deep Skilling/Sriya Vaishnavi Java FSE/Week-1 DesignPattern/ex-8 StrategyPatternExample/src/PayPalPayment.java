public class PayPalPayment implements PaymentStrategy{
    private String email;
    private String Password;
    public PayPalPayment(String email, String Password) {
        this.email = email;
        this.Password = Password;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paying " + amount + " to PayPal");
    }
}
