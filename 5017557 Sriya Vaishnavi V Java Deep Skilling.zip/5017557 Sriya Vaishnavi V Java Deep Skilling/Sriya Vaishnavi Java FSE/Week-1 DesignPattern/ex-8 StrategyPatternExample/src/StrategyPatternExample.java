public class StrategyPatternExample {
    public static void main(String[] args) {
           PaymentContext cart = new PaymentContext();

                // Pay using Credit Card
                cart.setPaymentStrategy(new CreditCardPayment("1234567890123456", 20000, 50000,"ABC"));
                cart.cart(100.0);

                System.out.println();

                // Pay using PayPal
                cart.setPaymentStrategy(new PayPalPayment("john.doe@example.com", "password"));
                cart.cart(200.0);

                System.out.println();


        }

    }
