public interface PaymentStrategy {
    public void pay(double amount);
}
