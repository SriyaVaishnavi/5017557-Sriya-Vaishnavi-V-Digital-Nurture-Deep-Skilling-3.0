public class PaymentContext {
    public PaymentStrategy paymentStrategy;
        public void setPaymentStrategy(PaymentStrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }
    public void cart(double amount){
            if (paymentStrategy == null){
                throw new NullPointerException("Payment strategy is null");
            }
            paymentStrategy.pay(amount);
    }

}
