public class WordDocumentFactory extends DocumentFactory {
    @Override
    protected document create() {
        return new WordDocument();
    }
}
