public class PDFDocumentFactory extends DocumentFactory {
    @Override
    protected document create() {
        return new PDFDocument();
    }
}