// Stripe Payment System
public class StripePayment {
    public void makePayment(double amount) {
        System.out.println("Processing Stripe payment of $" + amount);
    }
}
