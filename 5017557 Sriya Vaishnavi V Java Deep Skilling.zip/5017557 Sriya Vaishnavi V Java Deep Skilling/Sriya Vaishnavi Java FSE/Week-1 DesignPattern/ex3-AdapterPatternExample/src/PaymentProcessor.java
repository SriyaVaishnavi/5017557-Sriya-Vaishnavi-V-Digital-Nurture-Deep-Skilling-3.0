public interface PaymentProcessor {
    public void processPayment(double amount);
}
