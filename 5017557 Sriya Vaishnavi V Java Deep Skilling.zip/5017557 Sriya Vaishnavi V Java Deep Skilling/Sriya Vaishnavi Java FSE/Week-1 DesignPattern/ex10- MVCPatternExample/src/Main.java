public class Main {
    public static void main(String[] args) {
        // Create a new student
        Student student = new Student("184", "Cruise", "A");

        // Create the view
        StudentView view = new StudentView();

        // Create the controller
        StudentController controller = new StudentController(student, view);

        // Display initial details
        controller.updateView();

        // Update the student details
        controller.setStudentName("Cruise");
        controller.setStudentGrade("B");

        // Display updated details
        controller.updateView();
    }
}

