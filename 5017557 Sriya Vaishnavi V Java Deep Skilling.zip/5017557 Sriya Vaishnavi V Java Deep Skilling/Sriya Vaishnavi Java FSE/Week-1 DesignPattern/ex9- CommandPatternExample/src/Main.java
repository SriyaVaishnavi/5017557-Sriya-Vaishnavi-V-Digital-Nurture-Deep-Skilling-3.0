public class Main {
    public static void main(String[] args) {
        Light light = new Light();
        Command lightOn = new LightOn(light);
        Command lightOff = new LightOff(light);

        RemoteControl remote = new RemoteControl();

        // Turn the light on
        remote.setCommand(lightOn);
        remote.pressButton();

        // Turn the light off
        remote.setCommand(lightOff);
        remote.pressButton();
    }
}
